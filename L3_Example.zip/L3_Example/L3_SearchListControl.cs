﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace L3_Example
{
    [DefaultEvent("CurrentDataChanged")]
    public partial class L3_SearchListControl : UserControl
    {
        private delegate void SetDataCallBack(String sourceIP, String destinationIP, String protocol, int length, String timeStamp, byte[] data);

        public L3_SearchListControl()
        {
            InitializeComponent();
        }

        public void SetData(String sourceIP, String destinationIP, String protocol, int length, String timeStamp, byte[] data)
        {
            try
            {
                if (this.packetData.InvokeRequired)
                {
                    SetDataCallBack callback = new SetDataCallBack(SetData);
                    this.Invoke(callback, new object[] {sourceIP, destinationIP, protocol, length, timeStamp, data});
                }
                else
                {
                    String str_data = "";
                    for (int temp = 0; temp < length; temp++)
                    {
                        str_data += data[temp].ToString("X2") + " ";
                    }
                    this.packetData.Rows.Add(timeStamp, sourceIP, destinationIP, protocol, length, str_data);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void ReSet()
        {
            this.packetData.Rows.Clear();
        }

        private void packetData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            OnCurrentChanged(e.RowIndex);
        }


        public event EventHandler<CurrentChangedEventArgs> CurrentChanged;
        protected virtual void OnCurrentChanged(CurrentChangedEventArgs e)
        {
            if (CurrentChanged != null) CurrentChanged(this, e);
        }

        protected virtual void OnCurrentChanged(int index)
        {
            if (CurrentChanged != null) CurrentChanged(this, new CurrentChangedEventArgs(index));
        }

        public class CurrentChangedEventArgs : System.EventArgs
        {
            private int _index;

            public int Index
            {
                get { return _index; }
                set { _index = value; }
            }

            public CurrentChangedEventArgs(int index)
            {
                _index = index;
            }
        }
    }
}

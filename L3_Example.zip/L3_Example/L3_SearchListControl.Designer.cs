﻿namespace L3_Example
{
    partial class L3_SearchListControl
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.packetData = new System.Windows.Forms.DataGridView();
            this.TimeStamp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SourceIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DestinationIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Protocol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Length = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Information = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.packetData)).BeginInit();
            this.SuspendLayout();
            // 
            // packetData
            // 
            this.packetData.AllowUserToAddRows = false;
            this.packetData.AllowUserToDeleteRows = false;
            this.packetData.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.packetData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.packetData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.packetData.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TimeStamp,
            this.SourceIP,
            this.DestinationIP,
            this.Protocol,
            this.Length,
            this.Information});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.packetData.DefaultCellStyle = dataGridViewCellStyle2;
            this.packetData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.packetData.Location = new System.Drawing.Point(0, 0);
            this.packetData.Margin = new System.Windows.Forms.Padding(5);
            this.packetData.MultiSelect = false;
            this.packetData.Name = "packetData";
            this.packetData.ReadOnly = true;
            this.packetData.RowTemplate.Height = 23;
            this.packetData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.packetData.Size = new System.Drawing.Size(1230, 500);
            this.packetData.TabIndex = 0;
            this.packetData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.packetData_CellContentClick);
            // 
            // TimeStamp
            // 
            this.TimeStamp.Frozen = true;
            this.TimeStamp.HeaderText = "TimeStamp";
            this.TimeStamp.Name = "TimeStamp";
            this.TimeStamp.ReadOnly = true;
            this.TimeStamp.Width = 200;
            // 
            // SourceIP
            // 
            this.SourceIP.DividerWidth = 1;
            this.SourceIP.Frozen = true;
            this.SourceIP.HeaderText = "SourceIP";
            this.SourceIP.Name = "SourceIP";
            this.SourceIP.ReadOnly = true;
            this.SourceIP.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SourceIP.Width = 200;
            // 
            // DestinationIP
            // 
            this.DestinationIP.DividerWidth = 1;
            this.DestinationIP.Frozen = true;
            this.DestinationIP.HeaderText = "DestinationIP";
            this.DestinationIP.Name = "DestinationIP";
            this.DestinationIP.ReadOnly = true;
            this.DestinationIP.Width = 200;
            // 
            // Protocol
            // 
            this.Protocol.DividerWidth = 1;
            this.Protocol.Frozen = true;
            this.Protocol.HeaderText = "Protocol";
            this.Protocol.Name = "Protocol";
            this.Protocol.ReadOnly = true;
            // 
            // Length
            // 
            this.Length.DividerWidth = 1;
            this.Length.Frozen = true;
            this.Length.HeaderText = "Length";
            this.Length.Name = "Length";
            this.Length.ReadOnly = true;
            // 
            // Information
            // 
            this.Information.DividerWidth = 1;
            this.Information.Frozen = true;
            this.Information.HeaderText = "Packet Data";
            this.Information.Name = "Information";
            this.Information.ReadOnly = true;
            this.Information.Width = 480;
            // 
            // L3_SearchListControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.packetData);
            this.Name = "L3_SearchListControl";
            this.Size = new System.Drawing.Size(1230, 500);
            ((System.ComponentModel.ISupportInitialize)(this.packetData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView packetData;
        private System.Windows.Forms.DataGridViewTextBoxColumn TimeStamp;
        private System.Windows.Forms.DataGridViewTextBoxColumn SourceIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn DestinationIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn Protocol;
        private System.Windows.Forms.DataGridViewTextBoxColumn Length;
        private System.Windows.Forms.DataGridViewTextBoxColumn Information;
    }
}

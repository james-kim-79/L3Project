﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace L3_Example
{
    public partial class Form1 : Form
    {
        private Thread pcap_th = null;
        private Pcap pcap = null;

        public Form1()
        {
            InitializeComponent();
        }

        public void SetData(String sourceIP, String destinationIP, String protocol, int length, String timeStamp,
                      byte[] data)
        {
            l3_SearchListControl1.SetData(sourceIP, destinationIP, protocol, length, timeStamp, data); 
        }

        private void Search_ButtonClick(object sender, L3_SettingControl.SearchButtonClickedEventArgs e)
        {
            if (e.ClickEvent == 1)
            {
                if (pcap != null)
                {
                    l3_SearchListControl1.ReSet();
                    l3_SearchDataControl1.ReSet();
                }

                pcap = new Pcap(this, e.Filter, e.SelecedDevice);
                pcap_th = new Thread(new ThreadStart(this.pcap.Start_Pcap));
                pcap_th.Start();
            }
            else if (e.ClickEvent == 0)
            {
                pcap.Stop_Pcap();
            }
        }

        private void List_CurrentChanged(object sender, L3_SearchListControl.CurrentChangedEventArgs e)
        {
            l3_SearchDataControl1.SetData(((packet) pcap.packets[e.Index]).sourceIP,
                                         ((packet) pcap.packets[e.Index]).destinationIP,
                                         ((packet)pcap.packets[e.Index]).protocol,
                                         ((packet) pcap.packets[e.Index]).length,
                                         ((packet) pcap.packets[e.Index]).timeStamp,
                                         ((packet) pcap.packets[e.Index]).data);
        }
    }
}

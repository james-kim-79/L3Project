﻿namespace L3_Example
{
    partial class L3_SearchDataControl
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.sourceIp_txt = new System.Windows.Forms.TextBox();
            this.destinationIp_txt = new System.Windows.Forms.TextBox();
            this.protocol_txt = new System.Windows.Forms.TextBox();
            this.length_txt = new System.Windows.Forms.TextBox();
            this.info_txt = new System.Windows.Forms.TextBox();
            this.time_txt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(69, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "SourceIP : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(41, 60);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "DestinationIP : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(994, 61);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Protocol : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(1005, 100);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Length : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(41, 97);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Packet Data : ";
            // 
            // sourceIp_txt
            // 
            this.sourceIp_txt.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sourceIp_txt.Location = new System.Drawing.Point(165, 12);
            this.sourceIp_txt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.sourceIp_txt.Name = "sourceIp_txt";
            this.sourceIp_txt.ReadOnly = true;
            this.sourceIp_txt.Size = new System.Drawing.Size(231, 21);
            this.sourceIp_txt.TabIndex = 5;
            // 
            // destinationIp_txt
            // 
            this.destinationIp_txt.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.destinationIp_txt.Location = new System.Drawing.Point(165, 57);
            this.destinationIp_txt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.destinationIp_txt.Name = "destinationIp_txt";
            this.destinationIp_txt.ReadOnly = true;
            this.destinationIp_txt.Size = new System.Drawing.Size(231, 21);
            this.destinationIp_txt.TabIndex = 6;
            // 
            // protocol_txt
            // 
            this.protocol_txt.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.protocol_txt.Location = new System.Drawing.Point(1077, 58);
            this.protocol_txt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.protocol_txt.Name = "protocol_txt";
            this.protocol_txt.ReadOnly = true;
            this.protocol_txt.Size = new System.Drawing.Size(101, 21);
            this.protocol_txt.TabIndex = 7;
            // 
            // length_txt
            // 
            this.length_txt.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.length_txt.Location = new System.Drawing.Point(1076, 97);
            this.length_txt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.length_txt.Name = "length_txt";
            this.length_txt.ReadOnly = true;
            this.length_txt.Size = new System.Drawing.Size(102, 21);
            this.length_txt.TabIndex = 8;
            // 
            // info_txt
            // 
            this.info_txt.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.info_txt.Location = new System.Drawing.Point(44, 126);
            this.info_txt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.info_txt.Multiline = true;
            this.info_txt.Name = "info_txt";
            this.info_txt.ReadOnly = true;
            this.info_txt.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.info_txt.Size = new System.Drawing.Size(1134, 107);
            this.info_txt.TabIndex = 9;
            // 
            // time_txt
            // 
            this.time_txt.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.time_txt.Location = new System.Drawing.Point(1003, 15);
            this.time_txt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.time_txt.Name = "time_txt";
            this.time_txt.ReadOnly = true;
            this.time_txt.Size = new System.Drawing.Size(175, 21);
            this.time_txt.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(900, 18);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "TimeStamp : ";
            // 
            // L3_SearchDataControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.time_txt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.info_txt);
            this.Controls.Add(this.length_txt);
            this.Controls.Add(this.protocol_txt);
            this.Controls.Add(this.destinationIp_txt);
            this.Controls.Add(this.sourceIp_txt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "L3_SearchDataControl";
            this.Size = new System.Drawing.Size(1230, 250);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox sourceIp_txt;
        private System.Windows.Forms.TextBox destinationIp_txt;
        private System.Windows.Forms.TextBox protocol_txt;
        private System.Windows.Forms.TextBox length_txt;
        private System.Windows.Forms.TextBox info_txt;
        private System.Windows.Forms.TextBox time_txt;
        private System.Windows.Forms.Label label6;
    }
}

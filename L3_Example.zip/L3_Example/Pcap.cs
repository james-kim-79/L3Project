﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PcapDotNet.Core;
using PcapDotNet.Packets;
using PcapDotNet.Packets.IpV4;
using PcapDotNet.Packets.Transport;
using System.Windows.Forms;
using System.Collections;
using PcapDotNet.Packets.Arp;
namespace L3_Example
{
    class Pcap
    {
        private PacketDevice selectedDevice;
        private PacketCommunicator communicator;
        private Form1 wnd;
        private int[] filter;
        private int packetSet = 0;

        public ArrayList packets = new ArrayList();  

        public Pcap(Form1 wnd, int[] filter, PacketDevice selectedDevice)
        {
            this.filter = new int[filter.Length];
            this.filter = filter;
            this.selectedDevice = selectedDevice;
            this.wnd = wnd;
        }

        private void PacketHandler(Packet packet)
        {
            try
            {
                IpV4Datagram ip = packet.Ethernet.IpV4;
                UdpDatagram udp = ip.Udp;
                
                String protocol = "";

                byte[] data = new byte[packet.Length];
                packet.CopyTo(data, 0);


                // filter proccess //
                if (filter[0] == 1)
                {
                    if (data[12] == 0x08 && data[13] == 0x06)
                    {
                        protocol = "ARP";
                        packetSet = 1;
                    }
                    else if (data[12] == 0x08 && data[13] == 0x00)
                    {
                        if (data[23] == 0x01)
                        {
                            protocol = "ICMP";
                            packetSet = 1;
                        }
                        else if (data[23] == 0x06)
                        {
                            protocol = "TCP";
                            packetSet = 1;
                        }
                        else if (data[23] == 0x11)
                        {
                            protocol = "UDP";
                            packetSet = 1;
                        }
                    }
                }
                else if (filter[1] == 1)
                {
                    if (data[12] == 0x08 && data[13] == 0x06)
                    {
                        if (filter[3] == 1)
                        {
                            protocol = "ARP";
                            packetSet = 1;
                        }
                    }
                    else if (data[12] == 0x08 && data[13] == 0x00)
                    {
                        if (data[23] == 0x01)
                        {
                            if (filter[2] == 1)
                            {
                                protocol = "ICMP";
                                packetSet = 1;
                            }
                        }
                        else if (data[23] == 0x06)
                        {
                            if (filter[4] == 1)
                            {
                                protocol = "TCP";
                                packetSet = 1;
                            }
                        }
                        else if (data[23] == 0x11)
                        {
                            if (filter[5] == 1)
                            {
                                protocol = "UDP";
                                packetSet = 1;
                            }
                        }
                    }
                }

                if (packetSet == 1)
                {
                    packets.Add(new packet(ip.Source.ToString() + " : " + udp.SourcePort.ToString(), ip.Destination.ToString() + " : " + udp.DestinationPort.ToString(), protocol, packet.Length, packet.Timestamp.ToString("yyyy-MM-dd hh:mm:ss"), data));
                    this.wnd.SetData(ip.Source.ToString() + " : " + udp.SourcePort.ToString(), ip.Destination.ToString() + " : " + udp.DestinationPort.ToString(), protocol, packet.Length, packet.Timestamp.ToString("yyyy-MM-dd hh:mm:ss"), data);
                    packetSet = 0;
                }
            }
            catch (Exception ex)
            {
            }

        }
        public void Start_Pcap()
        {
            try
            {
                using (communicator = selectedDevice.Open(65536, PacketDeviceOpenAttributes.Promiscuous, 1000))
                {

                    if (communicator.DataLink.Kind != DataLinkKind.Ethernet)
                    {
                        Stop_Pcap();
                        MessageBox.Show("This program works only Ethernet Networks.");
                    }

                    communicator.ReceivePackets(0, PacketHandler);
                }
            }
            catch (Exception ex)
            {
                Stop_Pcap();
                MessageBox.Show(ex.Message);
            }
        }

        public void Stop_Pcap()
        {
            communicator.Break();
        }
    }
}

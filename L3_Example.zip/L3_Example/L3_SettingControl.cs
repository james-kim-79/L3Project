﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PcapDotNet.Core;
using PcapDotNet.Packets;

namespace L3_Example
{
    [DefaultEvent("SearchButtonClicked")]
    public partial class L3_SettingControl : UserControl
    {
        private IList<LivePacketDevice> allDevices;
        private PacketDevice selectedDevice;

        private int[] filter = new int[6];
        private int clickEvent = 0;

        public L3_SettingControl()
        {
            InitializeComponent();
        }

        private void select_Check_CheckedChanged(object sender, EventArgs e)
        {
            if (all_Check.Checked == true)
            {
                all_Check.Checked = false;
            }
            icmp_Check.Enabled = true;
            arp_Check.Enabled = true;
            tcp_Check.Enabled = true;
            udp_Check.Enabled = true;
        }

        private void all_Check_CheckedChanged(object sender, EventArgs e)
        {
            if (select_Check.Checked == true)
            {
                select_Check.Checked = false;
                icmp_Check.Checked = false;
                arp_Check.Checked = false;
                tcp_Check.Checked = false;
                udp_Check.Checked = false;
            }
            icmp_Check.Enabled = false;
            arp_Check.Enabled = false;
            tcp_Check.Enabled = false;
            udp_Check.Enabled = false;
        }

        private void search_Btn_Click(object sender, EventArgs e)
        {
            if (search_Btn.Text == "Search")
            {
                if (device_Combo.Text == "")
                {
                    MessageBox.Show("Choice Interface!");
                }
                else if (all_Check.Checked == false && select_Check.Checked == false)
                {
                    MessageBox.Show("Choice Filter!");
                }
                else
                {
                    //      ---- filter 초기화  ---- //
                    for (int temp = 0; temp < 6; temp++)
                    {
                        filter[temp] = 0;
                    }
                    //      ----------------------- //

                    selectedDevice = allDevices[device_Combo.SelectedIndex];
                    if (all_Check.Checked == true)
                    {
                        filter[0] = 1;
                    }
                    else
                    {
                        filter[1] = 1;
                        if (icmp_Check.Checked == true) filter[2] = 1;
                        if (arp_Check.Checked == true) filter[3] = 1;
                        if (tcp_Check.Checked == true) filter[4] = 1;
                        if (udp_Check.Checked == true) filter[5] = 1;
                    }
                    clickEvent = 1;
                    search_Btn.Text = "Stop";
                    OnSearchButtonClicked(clickEvent, selectedDevice, filter);
                }
            }
            else
            {
                clickEvent = 0;
                OnSearchButtonClicked(clickEvent, selectedDevice, filter);
                search_Btn.Text = "Search";
            }
        }

        private void L3_SettingControl_Load(object sender, EventArgs e)
        {
            try
            {
                allDevices = LivePacketDevice.AllLocalMachine;
                for (int i = 0; i != allDevices.Count; i++)
                {
                    LivePacketDevice device = allDevices[i];
                    device_Combo.Items.Add(device.Description);
                }
                search_Btn.Enabled = true;
            }
            catch (Exception)
            {
                MessageBox.Show("No Interfaces found! Make sure WinPcap is installed.");
            }
        }

        public event EventHandler<SearchButtonClickedEventArgs> SearchButtonClicked;

        protected virtual void OnSearchButtonClicked(SearchButtonClickedEventArgs e)
        {
            if (SearchButtonClicked != null)
            SearchButtonClicked(this, e);
        }
        protected virtual void OnSearchButtonClicked(int clickEvent, PacketDevice selectedDevice, int[] filter)
        {
            if(SearchButtonClicked != null)
            SearchButtonClicked(this, new SearchButtonClickedEventArgs(clickEvent, selectedDevice, filter));
        }

        public class SearchButtonClickedEventArgs : EventArgs
        {
            private int _clickEvent;
            private PacketDevice _selecedDevice;
            private int[] _filter;

            public int ClickEvent
            {
                get { return _clickEvent; }
                set { _clickEvent = value; }
            }

            public PacketDevice SelecedDevice
            {
                get { return _selecedDevice; }
                set { _selecedDevice = value; }
            }

            public int[] Filter
            {
                get { return _filter; }
                set { _filter = value; }
            }

            public SearchButtonClickedEventArgs(int clickEvent, PacketDevice selecedDevice, int[] filter)
            {
                _clickEvent = clickEvent;
                _selecedDevice = selecedDevice;
                _filter = filter;
            }
        }
        

    }
}

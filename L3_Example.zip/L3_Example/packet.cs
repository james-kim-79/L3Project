﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace L3_Example
{
    class packet
    {
        public String sourceIP = "";
        public String destinationIP = "";
        public String protocol = "";
        public int length = 0;
        public String timeStamp;
        public byte[] data;

        public packet(String sourceIP, String destinationIP, String protocol, int length, String timeStamp,
                      byte[] data)
        {
            this.sourceIP = sourceIP;
            this.destinationIP = destinationIP;
            this.protocol = protocol;
            this.length = length;
            this.timeStamp = timeStamp;
            this.data = new byte[length];
            this.data = data;
        }
    }
}

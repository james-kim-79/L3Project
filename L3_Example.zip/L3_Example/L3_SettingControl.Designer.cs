﻿namespace L3_Example
{
    partial class L3_SettingControl
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.device_Combo = new System.Windows.Forms.ComboBox();
            this.icmp_Check = new System.Windows.Forms.CheckBox();
            this.arp_Check = new System.Windows.Forms.CheckBox();
            this.tcp_Check = new System.Windows.Forms.CheckBox();
            this.udp_Check = new System.Windows.Forms.CheckBox();
            this.search_Btn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.select_Check = new System.Windows.Forms.CheckBox();
            this.all_Check = new System.Windows.Forms.CheckBox();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(31, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Device";
            // 
            // device_Combo
            // 
            this.device_Combo.FormattingEnabled = true;
            this.device_Combo.Location = new System.Drawing.Point(96, 28);
            this.device_Combo.Name = "device_Combo";
            this.device_Combo.Size = new System.Drawing.Size(424, 20);
            this.device_Combo.TabIndex = 1;
            // 
            // icmp_Check
            // 
            this.icmp_Check.AutoSize = true;
            this.icmp_Check.Enabled = false;
            this.icmp_Check.Location = new System.Drawing.Point(833, 20);
            this.icmp_Check.Name = "icmp_Check";
            this.icmp_Check.Size = new System.Drawing.Size(55, 16);
            this.icmp_Check.TabIndex = 1;
            this.icmp_Check.Text = "ICMP";
            this.icmp_Check.UseVisualStyleBackColor = true;
            // 
            // arp_Check
            // 
            this.arp_Check.AutoSize = true;
            this.arp_Check.Enabled = false;
            this.arp_Check.Location = new System.Drawing.Point(908, 21);
            this.arp_Check.Name = "arp_Check";
            this.arp_Check.Size = new System.Drawing.Size(48, 16);
            this.arp_Check.TabIndex = 2;
            this.arp_Check.Text = "ARP";
            this.arp_Check.UseVisualStyleBackColor = true;
            // 
            // tcp_Check
            // 
            this.tcp_Check.AutoSize = true;
            this.tcp_Check.Enabled = false;
            this.tcp_Check.Location = new System.Drawing.Point(832, 45);
            this.tcp_Check.Name = "tcp_Check";
            this.tcp_Check.Size = new System.Drawing.Size(49, 16);
            this.tcp_Check.TabIndex = 3;
            this.tcp_Check.Text = "TCP";
            this.tcp_Check.UseVisualStyleBackColor = true;
            // 
            // udp_Check
            // 
            this.udp_Check.AutoSize = true;
            this.udp_Check.Enabled = false;
            this.udp_Check.Location = new System.Drawing.Point(908, 45);
            this.udp_Check.Name = "udp_Check";
            this.udp_Check.Size = new System.Drawing.Size(48, 16);
            this.udp_Check.TabIndex = 4;
            this.udp_Check.Text = "UDP";
            this.udp_Check.UseVisualStyleBackColor = true;
            // 
            // search_Btn
            // 
            this.search_Btn.Enabled = false;
            this.search_Btn.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.search_Btn.ForeColor = System.Drawing.Color.Red;
            this.search_Btn.Location = new System.Drawing.Point(1091, 7);
            this.search_Btn.Name = "search_Btn";
            this.search_Btn.Size = new System.Drawing.Size(94, 64);
            this.search_Btn.TabIndex = 5;
            this.search_Btn.Text = "Search";
            this.search_Btn.UseVisualStyleBackColor = true;
            this.search_Btn.Click += new System.EventHandler(this.search_Btn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.select_Check);
            this.groupBox2.Controls.Add(this.all_Check);
            this.groupBox2.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.ForeColor = System.Drawing.Color.Blue;
            this.groupBox2.Location = new System.Drawing.Point(584, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(164, 61);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Filter";
            // 
            // select_Check
            // 
            this.select_Check.AutoSize = true;
            this.select_Check.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.select_Check.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.select_Check.Location = new System.Drawing.Point(86, 28);
            this.select_Check.Name = "select_Check";
            this.select_Check.Size = new System.Drawing.Size(65, 16);
            this.select_Check.TabIndex = 5;
            this.select_Check.Text = "Select";
            this.select_Check.UseVisualStyleBackColor = true;
            this.select_Check.CheckedChanged += new System.EventHandler(this.select_Check_CheckedChanged);
            // 
            // all_Check
            // 
            this.all_Check.AutoSize = true;
            this.all_Check.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.all_Check.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.all_Check.Location = new System.Drawing.Point(16, 27);
            this.all_Check.Name = "all_Check";
            this.all_Check.Size = new System.Drawing.Size(41, 16);
            this.all_Check.TabIndex = 0;
            this.all_Check.Text = "All";
            this.all_Check.UseVisualStyleBackColor = true;
            this.all_Check.CheckedChanged += new System.EventHandler(this.all_Check_CheckedChanged);
            // 
            // L3_SettingControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.search_Btn);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.udp_Check);
            this.Controls.Add(this.tcp_Check);
            this.Controls.Add(this.device_Combo);
            this.Controls.Add(this.arp_Check);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.icmp_Check);
            this.Name = "L3_SettingControl";
            this.Size = new System.Drawing.Size(1230, 80);
            this.Load += new System.EventHandler(this.L3_SettingControl_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox device_Combo;
        private System.Windows.Forms.CheckBox icmp_Check;
        private System.Windows.Forms.CheckBox arp_Check;
        private System.Windows.Forms.CheckBox tcp_Check;
        private System.Windows.Forms.CheckBox udp_Check;
        private System.Windows.Forms.Button search_Btn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox select_Check;
        private System.Windows.Forms.CheckBox all_Check;
    }
}

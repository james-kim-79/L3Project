﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace L3_Example
{
    public partial class L3_SearchDataControl : UserControl
    {
        public L3_SearchDataControl()
        {
            InitializeComponent();
        }

        public void SetData(String sourceIP, String destinationIP, String protocol, int length, String timeStamp, byte[] data)
        {
            this.sourceIp_txt.Text = sourceIP;
            this.destinationIp_txt.Text = destinationIP;
            this.protocol_txt.Text = protocol;
            this.length_txt.Text = length.ToString();
            this.time_txt.Text = timeStamp;

            String str_data = "";

            for (int temp = 0; temp < length; temp++)
            {
                str_data += data[temp].ToString("X2") + " ";
            }
            this.info_txt.Text = str_data;

        }

        public void ReSet()
        {
            this.sourceIp_txt.Text = " ";
            this.destinationIp_txt.Text = " ";
            this.protocol_txt.Text = " ";
            this.length_txt.Text = " ";
            this.time_txt.Text = " ";
            this.info_txt.Text = " ";
        }
    }
}

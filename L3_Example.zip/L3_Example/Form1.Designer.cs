﻿namespace L3_Example
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.l3_SearchListControl1 = new L3_Example.L3_SearchListControl();
            this.l3_SearchDataControl1 = new L3_Example.L3_SearchDataControl();
            this.l3_SettingControl1 = new L3_Example.L3_SettingControl();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.l3_SettingControl1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1232, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Setting";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.l3_SearchDataControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 611);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(5);
            this.panel1.Size = new System.Drawing.Size(1232, 250);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.l3_SearchListControl1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 100);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(5);
            this.panel2.Size = new System.Drawing.Size(1232, 511);
            this.panel2.TabIndex = 2;
            // 
            // l3_SearchListControl1
            // 
            this.l3_SearchListControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.l3_SearchListControl1.Location = new System.Drawing.Point(5, 5);
            this.l3_SearchListControl1.Name = "l3_SearchListControl1";
            this.l3_SearchListControl1.Size = new System.Drawing.Size(1222, 501);
            this.l3_SearchListControl1.TabIndex = 0;
            this.l3_SearchListControl1.CurrentChanged += new System.EventHandler<L3_Example.L3_SearchListControl.CurrentChangedEventArgs>(this.List_CurrentChanged);
            // 
            // l3_SearchDataControl1
            // 
            this.l3_SearchDataControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.l3_SearchDataControl1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.l3_SearchDataControl1.Location = new System.Drawing.Point(5, 5);
            this.l3_SearchDataControl1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.l3_SearchDataControl1.Name = "l3_SearchDataControl1";
            this.l3_SearchDataControl1.Size = new System.Drawing.Size(1222, 240);
            this.l3_SearchDataControl1.TabIndex = 0;
            // 
            // l3_SettingControl1
            // 
            this.l3_SettingControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.l3_SettingControl1.Location = new System.Drawing.Point(3, 17);
            this.l3_SettingControl1.Name = "l3_SettingControl1";
            this.l3_SettingControl1.Size = new System.Drawing.Size(1226, 80);
            this.l3_SettingControl1.TabIndex = 0;
            this.l3_SettingControl1.SearchButtonClicked += new System.EventHandler<L3_Example.L3_SettingControl.SearchButtonClickedEventArgs>(this.Search_ButtonClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1232, 861);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "L3_Example";
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private L3_SearchDataControl l3_SearchDataControl1;
        private L3_SearchListControl l3_SearchListControl1;
        private L3_SettingControl l3_SettingControl1;
    }
}

